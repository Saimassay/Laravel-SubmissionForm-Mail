@extends('layouts.master')
 
@section('content')
 
    <h2>Add a student</h2>
 
    <form method="post" action="/students" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label for="titleid" class="col-sm-3 col-form-label">Student</label>
            <div class="col-sm-9">
                <input name="name" type="text" class="form-control" id="titleid" placeholder="Name" required="" value="{{old('name')}}">
            </div>
        </div>
        <div class="form-group row">
            <label for="publisherid" class="col-sm-3 col-form-label">Grade</label>
            <div class="col-sm-9">
                <input name="grade" type="text" class="form-control" id="publisherid"
                       placeholder="grade" required="" value="{{old('grade')}}">
            </div>
        </div>
        
       
        <div class="form-group row">
            <div class="offset-sm-3 col-sm-9">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

          @include('partials.formerrors')
    </form>
 
@endsection