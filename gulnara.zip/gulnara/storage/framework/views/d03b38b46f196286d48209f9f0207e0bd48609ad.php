<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Students</title>
</head>
<body>
 
<ul>
   <?php foreach ($students as $student) : ?>
    <li><?= $student; ?></li>
    <?php endforeach; ?>
</ul>
 
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/gulnara/resources/views/students.blade.php ENDPATH**/ ?>