<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Hello!</h1>
</body>
</html><?php /**PATH /Applications/MAMP/htdocs/gulnara/resources/views/hello.blade.php ENDPATH**/ ?>