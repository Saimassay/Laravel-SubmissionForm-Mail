 
<?php $__env->startSection('content'); ?>
 
    <h2>Add a student</h2>
 
    <form method="post" action="/students" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group row">
            <label for="titleid" class="col-sm-3 col-form-label">Student</label>
            <div class="col-sm-9">
                <input name="name" type="text" class="form-control" id="titleid" placeholder="Name" required="" value="<?php echo e(old('name')); ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="publisherid" class="col-sm-3 col-form-label">Grade</label>
            <div class="col-sm-9">
                <input name="grade" type="text" class="form-control" id="publisherid"
                       placeholder="grade" required="" value="<?php echo e(old('grade')); ?>">
            </div>
        </div>
        
       
        <div class="form-group row">
            <div class="offset-sm-3 col-sm-9">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

          <?php echo $__env->make('partials.formerrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/gulnara/resources/views/students/create.blade.php ENDPATH**/ ?>